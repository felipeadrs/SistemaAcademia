package dao;

import model.Treino;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TreinoDAO {
    private final String url = "jdbc:mysql://localhost:3306/academia?useSSL=false&serverTimezone=UTC";
    private final String user = "root";
    private final String password = "";

    public void cadastrar(Treino treino) throws SQLException {
        String sql = "INSERT INTO treinos (aluno_id, data_inicio, descricao, duracao_minutos, tipo_treino) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            if (treino.getAlunoId() != null) {
                stmt.setInt(1, treino.getAlunoId());
            } else {
                stmt.setNull(1, Types.INTEGER);
            }

            if (treino.getDataInicio() != null) {
                stmt.setDate(2, Date.valueOf(treino.getDataInicio()));
            } else {
                stmt.setNull(2, Types.DATE);
            }

            if (treino.getDescricao() != null) {
                stmt.setString(3, treino.getDescricao());
            } else {
                stmt.setNull(3, Types.VARCHAR);
            }

            if (treino.getDuracaoMinutos() != null) {
                stmt.setInt(4, treino.getDuracaoMinutos());
            } else {
                stmt.setNull(4, Types.INTEGER);
            }

            if (treino.getTipoTreino() != null) {
                stmt.setString(5, treino.getTipoTreino());
            } else {
                stmt.setNull(5, Types.VARCHAR);
            }

            int affectedRows = stmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Falha ao inserir treino, nenhuma linha afetada.");
            }

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    treino.setId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Falha ao obter ID do treino.");
                }
            }
        }
    }

    public List<Treino> listarPorAluno(Integer alunoId) throws SQLException {
        List<Treino> lista = new ArrayList<>();
        String sql = "SELECT id, aluno_id, data_inicio, descricao, duracao_minutos, tipo_treino FROM treinos WHERE aluno_id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            if (alunoId != null) {
                stmt.setInt(1, alunoId);
            } else {
                stmt.setNull(1, Types.INTEGER);
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("id");

                    Integer aId = rs.getInt("aluno_id");
                    if (rs.wasNull()) aId = null;

                    Date dt = rs.getDate("data_inicio");
                    LocalDate dataInicio = dt != null ? dt.toLocalDate() : null;

                    String descricao = rs.getString("descricao");
                    if (rs.wasNull()) descricao = null;

                    Integer duracao = rs.getInt("duracao_minutos");
                    if (rs.wasNull()) duracao = null;

                    String tipoTreino = rs.getString("tipo_treino");
                    if (rs.wasNull()) tipoTreino = null;

                    Treino treino = new Treino(id, aId, dataInicio, descricao, duracao, tipoTreino);
                    lista.add(treino);
                }
            }
        }

        return lista;
    }

    public void atualizar(Treino treino) throws SQLException {
        String sql = "UPDATE treinos SET aluno_id = ?, data_inicio = ?, descricao = ?, duracao_minutos = ?, tipo_treino = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            if (treino.getAlunoId() != null) {
                stmt.setInt(1, treino.getAlunoId());
            } else {
                stmt.setNull(1, Types.INTEGER);
            }

            if (treino.getDataInicio() != null) {
                stmt.setDate(2, Date.valueOf(treino.getDataInicio()));
            } else {
                stmt.setNull(2, Types.DATE);
            }

            if (treino.getDescricao() != null) {
                stmt.setString(3, treino.getDescricao());
            } else {
                stmt.setNull(3, Types.VARCHAR);
            }

            if (treino.getDuracaoMinutos() != null) {
                stmt.setInt(4, treino.getDuracaoMinutos());
            } else {
                stmt.setNull(4, Types.INTEGER);
            }

            if (treino.getTipoTreino() != null) {
                stmt.setString(5, treino.getTipoTreino());
            } else {
                stmt.setNull(5, Types.VARCHAR);
            }

            stmt.setInt(6, treino.getId());

            stmt.executeUpdate();
        }
    }

    public void deletar(int id) throws SQLException {
        String sql = "DELETE FROM treinos WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}
