package AcademiaCRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestaConexao {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/academia?useSSL=false&serverTimezone=UTC";
        String user = "root";
        String password = ""; // padrão do XAMPP

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            System.out.println("✅ Conexão com o banco de dados foi bem-sucedida!");
        } catch (SQLException e) {
            System.out.println("❌ Erro ao conectar: " + e.getMessage());
        }
    }
}
