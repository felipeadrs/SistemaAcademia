package trabalho.academiacrud;

import dao.AlunoDAO;
import dao.TreinoDAO;
import model.Aluno;
import model.Treino;

import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.sql.SQLException;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        AlunoDAO alunoDAO = new AlunoDAO();
        TreinoDAO treinoDAO = new TreinoDAO();

        while (true) {
            System.out.println("\n--- Menu ---");
            System.out.println("1. Cadastrar Aluno");
            System.out.println("2. Listar Alunos");
            System.out.println("3. Cadastrar Treino");
            System.out.println("4. Listar Treinos por Aluno");
            System.out.println("5. Atualizar Treino");
            System.out.println("6. Deletar Treino");
            System.out.println("0. Sair");
            System.out.print("Escolha: ");

            int op;
            try {
                op = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Digite um número.");
                continue;
            }

            try {
                switch (op) {
                    case 1 -> {
                        System.out.print("Nome: ");
                        String nome = sc.nextLine();

                        System.out.print("CPF: ");
                        String cpf = sc.nextLine();

                        System.out.print("Data Nascimento (YYYY-MM-DD): ");
                        String dataStr = sc.nextLine();

                        LocalDate dataNascimento;
                        try {
                            dataNascimento = LocalDate.parse(dataStr, DateTimeFormatter.ISO_LOCAL_DATE);
                        } catch (DateTimeParseException e) {
                            System.out.println("Data inválida! Use o formato YYYY-MM-DD.");
                            continue;
                        }

                        System.out.print("Telefone: ");
                        String tel = sc.nextLine();

                        System.out.print("Email: ");
                        String email = sc.nextLine();

                        alunoDAO.cadastrar(new Aluno(nome, cpf, dataNascimento, tel, email));
                        System.out.println("Aluno cadastrado!");
                    }
                    case 2 -> {
                        System.out.println("\nLista de Alunos:");
                        List<Aluno> alunos = alunoDAO.listarTodos();
                        if (alunos.isEmpty()) {
                            System.out.println("Nenhum aluno cadastrado.");
                        } else {
                            for (Aluno a : alunos) {
                                System.out.println(a.getId() + " - " + a.getNome() + " - Nasc: " + a.getDataNascimento());
                            }
                        }
                    }
                    case 3 -> {
                        System.out.print("ID do Aluno (pode deixar vazio): ");
                        String alunoIdStr = sc.nextLine();
                        Integer alunoId = null;
                        if (!alunoIdStr.isBlank()) {
                            try {
                                alunoId = Integer.parseInt(alunoIdStr);
                            } catch (NumberFormatException e) {
                                System.out.println("ID inválido.");
                                continue;
                            }
                        }

                        System.out.print("Data Início (YYYY-MM-DD) (pode deixar vazio): ");
                        String dataInicioStr = sc.nextLine();
                        LocalDate dataInicio = null;
                        if (!dataInicioStr.isBlank()) {
                            try {
                                dataInicio = LocalDate.parse(dataInicioStr, DateTimeFormatter.ISO_LOCAL_DATE);
                            } catch (DateTimeParseException e) {
                                System.out.println("Data inválida! Use o formato YYYY-MM-DD.");
                                continue;
                            }
                        }

                        System.out.print("Descrição (pode deixar vazio): ");
                        String descricao = sc.nextLine();
                        if (descricao.isBlank()) descricao = null;

                        System.out.print("Duração em minutos (pode deixar vazio): ");
                        String duracaoStr = sc.nextLine();
                        Integer duracao = null;
                        if (!duracaoStr.isBlank()) {
                            try {
                                duracao = Integer.parseInt(duracaoStr);
                            } catch (NumberFormatException e) {
                                System.out.println("Duração inválida.");
                                continue;
                            }
                        }

                        System.out.print("Tipo de Treino (pode deixar vazio): ");
                        String tipoTreino = sc.nextLine();
                        if (tipoTreino.isBlank()) tipoTreino = null;

                        Treino treino = new Treino(alunoId, dataInicio, descricao, duracao, tipoTreino);
                        treinoDAO.cadastrar(treino);
                        System.out.println("Treino cadastrado com ID: " + treino.getId());
                    }
                    case 4 -> {
                        System.out.print("ID do Aluno para listar treinos: ");
                        String alunoIdStr = sc.nextLine();
                        int alunoId;
                        try {
                            alunoId = Integer.parseInt(alunoIdStr);
                        } catch (NumberFormatException e) {
                            System.out.println("ID inválido.");
                            continue;
                        }

                        List<Treino> treinos = treinoDAO.listarPorAluno(alunoId);
                        if (treinos.isEmpty()) {
                            System.out.println("Nenhum treino encontrado para este aluno.");
                        } else {
                            System.out.println("\nTreinos do aluno " + alunoId + ":");
                            for (Treino t : treinos) {
                                System.out.printf("ID: %d | Data: %s | Descrição: %s | Duração: %s min | Tipo: %s\n",
                                        t.getId(),
                                        t.getDataInicio() != null ? t.getDataInicio() : "N/A",
                                        t.getDescricao() != null ? t.getDescricao() : "N/A",
                                        t.getDuracaoMinutos() != null ? t.getDuracaoMinutos() : "N/A",
                                        t.getTipoTreino() != null ? t.getTipoTreino() : "N/A"
                                );
                            }
                        }
                    }
                    case 5 -> {
                        System.out.print("ID do Treino a atualizar: ");
                        int id = Integer.parseInt(sc.nextLine());

                        System.out.print("Nova Descrição (pode deixar vazio): ");
                        String desc = sc.nextLine();
                        if (desc.isBlank()) desc = null;

                        System.out.print("Nova Duração em minutos (pode deixar vazio): ");
                        String dur = sc.nextLine();
                        Integer duracao = null;
                        if (!dur.isBlank()) {
                            try {
                                duracao = Integer.parseInt(dur);
                            } catch (NumberFormatException e) {
                                System.out.println("Valor inválido para duração.");
                                continue;
                            }
                        }

                        System.out.print("Novo Tipo de Treino (pode deixar vazio): ");
                        String tipo = sc.nextLine();
                        if (tipo.isBlank()) tipo = null;

                        Treino treinoAtualizado = new Treino();
                        treinoAtualizado.setId(id);
                        treinoAtualizado.setDescricao(desc);
                        treinoAtualizado.setDuracaoMinutos(duracao);
                        treinoAtualizado.setTipoTreino(tipo);

                        treinoDAO.atualizar(treinoAtualizado);
                        System.out.println("Treino atualizado!");
                    }
                    case 6 -> {
                        System.out.print("ID do Treino a deletar: ");
                        int idTreino = Integer.parseInt(sc.nextLine());
                        treinoDAO.deletar(idTreino);
                        System.out.println("Treino deletado com sucesso.");
                    }
                    case 0 -> {
                        System.out.println("Saindo...");
                        sc.close();
                        return;
                    }
                    default -> System.out.println("Opção inválida");
                }
            } catch (SQLException e) {
                System.out.println("Erro ao acessar o banco de dados: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Erro inesperado: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}
