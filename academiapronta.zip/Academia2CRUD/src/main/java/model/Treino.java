package model;

import java.time.LocalDate;

public class Treino {
    private int id;
    private Integer alunoId;  // como pode ser NULL, usamos Integer
    private LocalDate dataInicio;
    private String descricao;
    private Integer duracaoMinutos;
    private String tipoTreino;

    public Treino() {}

    public Treino(int id, Integer alunoId, LocalDate dataInicio, String descricao, Integer duracaoMinutos, String tipoTreino) {
        this.id = id;
        this.alunoId = alunoId;
        this.dataInicio = dataInicio;
        this.descricao = descricao;
        this.duracaoMinutos = duracaoMinutos;
        this.tipoTreino = tipoTreino;
    }

    public Treino(Integer alunoId, LocalDate dataInicio, String descricao, Integer duracaoMinutos, String tipoTreino) {
        this.alunoId = alunoId;
        this.dataInicio = dataInicio;
        this.descricao = descricao;
        this.duracaoMinutos = duracaoMinutos;
        this.tipoTreino = tipoTreino;
    }

    // getters e setters

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Integer getAlunoId() { return alunoId; }
    public void setAlunoId(Integer alunoId) { this.alunoId = alunoId; }

    public LocalDate getDataInicio() { return dataInicio; }
    public void setDataInicio(LocalDate dataInicio) { this.dataInicio = dataInicio; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public Integer getDuracaoMinutos() { return duracaoMinutos; }
    public void setDuracaoMinutos(Integer duracaoMinutos) { this.duracaoMinutos = duracaoMinutos; }

    public String getTipoTreino() { return tipoTreino; }
    public void setTipoTreino(String tipoTreino) { this.tipoTreino = tipoTreino; }
}
